from flask import Flask, render_template, request, send_file, session
import pandas as pd
from bs4 import BeautifulSoup
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
import time

app = Flask(__name__)
app.secret_key = b'_5#y2L"F4Q8z\n\xec]/'

def scrape_ads_info(site_web, min_pub):
    # Initialize Chrome WebDriver
    service = Service('C:/Users/pc/Desktop/windows app/chromedriver-win64/chromedriver.exe')
    options = Options()
    options.add_argument("--headless")
    navigateur = webdriver.Chrome(service=service, options=options)

    # URL du lien à ouvrir
    url = f"https://web.facebook.com/ads/library/?active_status=all&ad_type=all&country=ALL&q={site_web}&sort_data[direction]=desc&sort_data[mode]=relevancy_monthly_grouped&search_type=keyword_unordered&media_type=all"

    # Ouvrir le lien dans le navigateur
    navigateur.get(url)
    time.sleep(15)
    # Récupérer le contenu de la page
    code_source_page = navigateur.page_source

    # Analyser le code source de la page avec BeautifulSoup
    soup = BeautifulSoup(code_source_page, "html.parser")

    # Trouver tous les éléments div avec les classes spécifiées
    elements_div = soup.find_all("div", class_="xexx8yu xn6708d x18d9i69 xkhd6sd")

    # Extraire le nombre de résultats
    nb_resultats = int(elements_div[0].find("div", class_="x8t9es0 x1uxerd5 xrohxju x108nfp6 xq9mrsl x1h4wwuj x117nqv4 xeuugli").text.split()[0])

    # Extraire les informations sur chaque publicité
    publicites = []
    pub_elements = soup.find_all("div", class_="x6s0dn4 x78zum5 xsag5q8")
    for pub_element in pub_elements:
        pub_info = pub_element.find("strong")
        if pub_info:
            nb_pub = ''.join(filter(str.isdigit, pub_info.text.strip()))
            publicites.append(nb_pub)
    
    # Extraire l'ID et l'état
    id_element = soup.find("span", class_="x8t9es0 xw23nyj xo1l8bm x63nzvj x108nfp6 xq9mrsl x1h4wwuj xeuugli")
    etat_element = soup.find("span", class_="x8t9es0 xw23nyj xo1l8bm x63nzvj x108nfp6 xq9mrsl x1h4wwuj xeuugli x1i64zmx")

    id_str = "https://web.facebook.com/ads/library/?id=" + id_element.text.strip().split(":")[1].strip() if id_element else "N/A"
    etat = etat_element.text.strip() if etat_element else "N/A"

    # Close the browser
    navigateur.quit()

    # Initialize an empty list to store results
    results_list = []

    # Add results to the list
    for i, nb_pub in enumerate(publicites, 1):
        if int(nb_pub) >= min_pub:
            results_list.append({'Domain': site_web, 'Total camping': nb_resultats, 'Status': etat, 'C1D': nb_pub, 'C1C': id_str})
    
    return results_list

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/submit', methods=['POST'])
def submit():
    file = request.files['file']
    min_ad_count = int(request.form['min_ad_count'])

    file.save('uploaded_file.xlsx')

    # Read the uploaded Excel file into a DataFrame
    dfx = pd.read_excel('uploaded_file.xlsx')

    # Check if the file contains at least one domain name
    if len(dfx) == 0:
        # Handle empty file case here
        return "File is empty."

    # Liste pour stocker les résultats affichés
    displayed_results = []

    # Extract domain names from the DataFrame
    domain_names = dfx.iloc[:, 0].tolist()

    for domain_name in domain_names:
        # Scrape ads info for each domain
        results = scrape_ads_info(domain_name, min_ad_count)
        displayed_results.extend(results)
    
    # Créer un DataFrame à partir de la liste de résultats affichés
    df = pd.DataFrame(displayed_results, columns=["Domain", "Total camping", "Status", "C1D", "C1C"])

    # Sauvegarder le DataFrame au format Excel
    df.to_excel("results.xlsx", index=False)

    return send_file("results.xlsx", as_attachment=True)

if __name__ == '__main__':
    app.run(debug=True)